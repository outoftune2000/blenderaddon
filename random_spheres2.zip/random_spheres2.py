bl_info = {
    "name": "Random Spheres",
    "author": "outoftune2000",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > N",
    "description": "Adds a random Mesh Object",
    "warning": "",
    "doc_url": "",
    "category": "",
}


import bpy
from bpy.types import (Panel , Operator)
from random import randint
def WireWave():
    bpy.ops.object.modifier_add(type='WAVE')
    bpy.context.object.modifiers["Wave"].use_normal = True
    bpy.ops.object.modifier_add(type ='WIREFRAME')
    bpy.context.object.modifiers["Wireframe"].thickness = 0.0135
    bpy.ops.object.make_links_data(type='MODIFIERS')
        



class ButtonOperator(bpy.types.Operator):
    bl_idname = "random_spheres.1"
    bl_label = "Simple random Operator"
    
    def execute(self, context):
        for i in range(100):
            RandomScale = randint(0,3)
            x = randint(-40,40)
            y = randint(-40,40)
            z= randint(-40,40)
            bpy.ops.mesh.primitive_uv_sphere_add( radius = randomScale , enter_editmode = False , align = 'WORLD' , location = (x,y,z))
            bpy.ops.object.shade_smooth()
        return {'FINISHED'}
class CustomPanel(bpy.types.Panel):
    bl_label = "random sphere Panel"
    bl_idname = "OBJECT_PT_random"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "object"

    def draw(self, context):
        layout = self.layout
    
        obj = context.object

        row = layout.row()
        row.label(ButtonOperator.bl_idname , text = "generate", icon='COMMUNITY')

from bpy.utils import register_class , unregister_class
_classes = [
    ButtonOperator,
    CustomPanel
    ]


def register():
    for cls in _classes:
        register_class(cls)


def unregister():
    for cls in _classes:
        unregister_class(cls)    

if __name__ == "__main__":
    register()
